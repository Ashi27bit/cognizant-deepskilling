# Cognizant React JS Hands-On Labs

This repository contains completed solutions for all 19 React hands-on lab exercises from the Cognizant Academy training program.

## Structure

| # | Folder | Topic |
|---|--------|-------|
| 1 | 01-myfirstreact | Setting up a React environment, create-react-app |
| 2 | 02-StudentApp | Class components (Home, About, Contact) |
| 3 | 03-scorecalculatorapp | Function components + inline/CSS styling |
| 4 | 04-blogapp | Component lifecycle (componentDidMount, componentDidCatch) |
| 5 | 05-CohortDashboard | CSS Modules & inline styling |
| 6 | 06-TrainersApp | React Router (BrowserRouter, Routes, Link, useParams) |
| 7 | 07-shoppingapp | Props |
| 8 | 08-counterapp | React State |
| 9 | 09-cricketapp | ES6 features (map, arrow functions, destructuring, spread) |
| 10 | 10-officespacerentalapp | JSX |
| 11 | 11-eventexamplesapp | React events & synthetic events |
| 12 | 12-ticketbookingapp | Conditional rendering (Guest vs Logged-in) |
| 13 | 13-bloggerapp | Multiple conditional rendering techniques |
| 14 | 14-EmployeeContextApp | React Context API |
| 15 | 15-ticketraisingapp | React Forms |
| 16 | 16-mailregisterapp | React Forms validation |
| 17 | 17-fetchuserapp | Consuming REST APIs |
| 18 | 18-CohortDashboard-Tests | Unit testing with Jest & Enzyme |
| 19 | 19-gitclientapp | Isolation testing & mocking with Jest |

## How to use each lab

Each folder contains only the modified/added `src` files (not a full `node_modules`/scaffold, to keep the repo lightweight) plus a `README.md` with exact setup steps. In general:

```bash
npx create-react-app <app-name>
cd <app-name>
# copy the src files from the matching lab folder into your generated src/ folder
npm install <any-extra-packages-mentioned-in-that-lab's-README>
npm start
```

## Uploading to GitHub

```bash
git init
git add .
git commit -m "Add all 19 React hands-on lab solutions"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

## Notes
- Labs 6, 18, and 19 require extra npm packages (`react-router-dom`, `enzyme` + adapter, `axios`) — see each lab's own README.
- Labs 4, 17, and 19 call live public APIs (jsonplaceholder, randomuser.me, api.github.com) and need internet access when running `npm start`.
